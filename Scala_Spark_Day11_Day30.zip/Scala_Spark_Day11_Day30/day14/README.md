# Day 14 — DataFrame and Dataset
Tasks: case class -> Dataset -> DataFrame; compare RDD/DataFrame/Dataset; type safety and Catalyst. Run `sbt "runMain day14.DataFrameDatasetApp"`.
