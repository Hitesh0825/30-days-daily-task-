# Day 24 — Stateless vs Stateful Streaming
Input format: `account:amount`. Uses updateStateByKey to maintain running account totals. Start `nc -lk 9998`, then run `sbt "runMain day24.StatefulStreamingApp"`. Compare current-batch output with accumulated state.
