# Day 15 — UDF
Tasks: salary-band UDF, withColumn, registered UDF, compare with built-ins. Run `sbt "runMain day15.UdfApp"`. Built-ins are normally preferable for optimizer/code-generation support.
