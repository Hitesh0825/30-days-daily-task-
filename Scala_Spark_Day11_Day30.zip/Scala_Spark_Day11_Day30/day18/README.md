# Day 18 — Joins
Tasks: inner/left/right/full joins; aliases for ambiguous columns; null handling; shuffle-sort-merge join concept. Run `sbt "runMain day18.JoinsApp"`.
