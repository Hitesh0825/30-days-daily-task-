# Day 25 — Window Operations
Uses 5-second batches, 20-second windows and 10-second sliding interval. Demonstrates countByWindow and reduceByKeyAndWindow. Start `nc -lk 9997`, then run `sbt "runMain day25.WindowOperationsApp"`.
