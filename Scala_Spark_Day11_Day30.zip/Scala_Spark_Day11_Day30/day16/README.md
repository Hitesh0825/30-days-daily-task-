# Day 16 — Aggregations
Tasks: count/sum/avg/min/max; groupBy multiple business dimensions; HAVING-like filtering; department salary metrics. Run `sbt "runMain day16.AggregationsApp"`.
