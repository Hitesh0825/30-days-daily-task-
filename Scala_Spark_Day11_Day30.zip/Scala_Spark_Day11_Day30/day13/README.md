# Day 13 — Spark SQL Basics
Tasks: DataFrame, schema inspection, select/filter, withColumn, temporary view, SQL analytics report. Run `sbt "runMain day13.SparkSqlBasicsApp"`.
