# Day 23 — DStreams Basics
Creates a 5-second micro-batch socket stream and counts ERROR tokens. Start a producer such as `nc -lk 9999`, then run `sbt "runMain day23.DStreamsBasicsApp"`. DStreams are the requested legacy API practice; for new production systems prefer Structured Streaming.
