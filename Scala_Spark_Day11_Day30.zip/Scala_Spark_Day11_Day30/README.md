# Scala + Apache Spark — Day 11 to Day 30

Complete runnable practice pack based on the uploaded **Scala + Apache Spark 30-Day Daily Practice Problem Set**.

## Requirements
- JDK 17
- Scala 2.13.18
- sbt 1.11+
- Apache Spark 4.2.0

## Run
```bash
sbt compile
sbt "runMain day11.BroadcastAccumulatorApp"
```

Each day is under `src/main/scala/dayXX/` and has a dedicated `Main` object. Sample data is under `data/`.

## Days
11 Broadcast + Accumulator  
12 Cache + Persist  
13 Spark SQL Basics  
14 DataFrame + Dataset  
15 UDF  
16 Aggregations  
17 Window Functions  
18 Joins  
19 Broadcast Join  
20 File Formats + Output  
21 Spark Catalog  
22 Batch E-commerce Pipeline  
23 DStreams Basics  
24 Stateful/Stateless Streaming  
25 Window Operations  
26 Healthcare Real-Time Project  
27 Banking Real-Time Project  
28 Booking Real-Time Project  
29 E-commerce End-to-End Project  
30 Final Capstone + Interview Questions

## Important
The original task sheet explicitly asks you to write, test, inspect results, and explain transformations, actions, partitions, shuffle boundaries and optimizations. Use the README in each day folder as the checklist.
