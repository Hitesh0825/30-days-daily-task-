# Day 20 — File Formats and Output
Tasks: CSV/JSON/Parquet read-write patterns; partitioned output; output file layout; repartition before writing. Run `sbt "runMain day20.FileFormatsApp"`. Outputs appear under `output/day20/`.
