# Day 21 — Spark Catalog
Tasks: list databases/tables, temporary views, register/query tables, inspect metadata. Run `sbt "runMain day21.SparkCatalogApp"`.
