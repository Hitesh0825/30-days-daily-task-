# Day 12 — Cache and Persist
Tasks: reuse cleaned RDD for multiple actions; compare cache/persist; try MEMORY_ONLY and MEMORY_AND_DISK; understand when caching hurts. Run `sbt "runMain day12.CachePersistApp"`.
