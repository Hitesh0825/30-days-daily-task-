package day19
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object BroadcastJoinApp extends App {
  val spark=SparkSession.builder().appName("Day19").master("local[*]").getOrCreate(); import spark.implicits._
  val facts=spark.range(1,1000001).toDF("txn_id").withColumn("branch_id",($"txn_id"%3).cast("int")).withColumn("amount",($"txn_id"%1000).cast("double"))
  val branches=Seq((0,"Hyderabad"),(1,"Delhi"),(2,"Roorkee")).toDF("branch_id","branch")
  facts.join(broadcast(branches),Seq("branch_id")).groupBy("branch").sum("amount").show()
  println("Broadcast is suitable when the small side fits safely in executor memory; otherwise use shuffle join."); spark.stop()
}
