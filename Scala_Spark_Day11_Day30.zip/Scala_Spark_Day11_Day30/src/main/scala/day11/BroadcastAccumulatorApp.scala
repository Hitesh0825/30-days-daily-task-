package day11
import org.apache.spark.sql.SparkSession

object BroadcastAccumulatorApp extends App {
  val spark = SparkSession.builder().appName("Day11").master("local[*]").getOrCreate()
  val sc = spark.sparkContext
  val productRef = sc.broadcast(Map("P100" -> 100, "P200" -> 250, "P300" -> 500))
  val badRecords = sc.longAccumulator("badRecords")
  val tx = sc.parallelize(Seq(("A1","P100",2),("A2","P200",1),("A3","P999",3),("A4","P300",-1)))
  val validated = tx.map { case (account,pid,qty) =>
    productRef.value.get(pid) match {
      case Some(price) if qty > 0 => (account,pid,qty,price,qty*price,"VALID")
      case _ => badRecords.add(1); (account,pid,qty,0,0,"BAD")
    }
  }
  validated.collect().foreach(println)
  println(s"Bad records = ${badRecords.value}")
  spark.stop()
}
