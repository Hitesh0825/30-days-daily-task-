package day26
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object HealthcareRealtimeProject extends App {
  val spark=SparkSession.builder().appName("Day26").master("local[*]").getOrCreate(); import spark.implicits._
  case class Vital(patientId:String,ts:String,heartRate:Int,temperature:Double,spo2:Int)
  val thresholds=spark.sparkContext.broadcast(Map("heartRateMax"->120,"tempMax"->38.0,"spo2Min"->92))
  val abnormal=spark.sparkContext.longAccumulator("abnormalVitals")
  val vitals=spark.sparkContext.parallelize(Seq(Vital("P1","10:00",88,37.0,98),Vital("P2","10:01",145,38.7,89),Vital("P1","10:02",130,37.2,95)))
  val alerts=vitals.map{v=>val t=thresholds.value; val bad=v.heartRate>t("heartRateMax") || v.temperature>t("tempMax") || v.spo2<t("spo2Min"); if(bad) abnormal.add(1); (v.patientId,v.ts,v.heartRate,v.temperature,v.spo2,bad)}
  alerts.collect().foreach(println); println(s"Abnormal events=${abnormal.value}"); println("Production extension: Structured Streaming/Kafka input, watermark/window for repeated abnormal readings, checkpointing and alert sink."); spark.stop()
}
