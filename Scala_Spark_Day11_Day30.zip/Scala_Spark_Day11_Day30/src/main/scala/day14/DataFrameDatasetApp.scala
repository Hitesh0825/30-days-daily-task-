package day14
import org.apache.spark.sql.SparkSession
object DataFrameDatasetApp extends App {
  case class Employee(id:Int,name:String,dept:String,salary:Double)
  val spark=SparkSession.builder().appName("Day14").master("local[*]").getOrCreate(); import spark.implicits._
  val ds=Seq(Employee(1,"Asha","IT",70000),Employee(2,"Ravi","HR",60000),Employee(3,"Neha","IT",90000)).toDS()
  ds.show(); ds.filter(_.salary>65000).map(e=>(e.name,e.salary*12)).toDF("name","annual_salary").show()
  println("RDD = low-level control; DataFrame = untyped structured API; Dataset = typed JVM API + Catalyst/Tungsten optimizations")
  spark.stop()
}
