package day24
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds,StreamingContext}
object StatefulStreamingApp extends App {
  val conf=new SparkConf().setAppName("Day24").setMaster("local[2]"); val ssc=new StreamingContext(conf,Seconds(5)); ssc.checkpoint("output/day24/checkpoint")
  val stream=ssc.socketTextStream("localhost",9998)
  val pairs=stream.flatMap(_.split("\\s+")).filter(_.contains(":" )).map{x=> val p=x.split(":",2); (p(0),p(1).toLong)}
  val running=pairs.updateStateByKey[Long]{(values,state)=>Some(values.sum+state.getOrElse(0L))}
  running.print(); println("Stateless: current batch only. Stateful: previous state + current batch. Input example: A1:100")
  ssc.start(); ssc.awaitTerminationOrTimeout(30000); ssc.stop(true,true)
}
