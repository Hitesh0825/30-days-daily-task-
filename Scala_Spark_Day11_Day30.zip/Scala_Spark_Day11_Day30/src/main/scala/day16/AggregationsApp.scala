package day16
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object AggregationsApp extends App {
  val spark=SparkSession.builder().appName("Day16").master("local[*]").getOrCreate(); import spark.implicits._
  val df=Seq(("IT","Asha",70000.0),("IT","Ravi",90000.0),("HR","Neha",60000.0),("HR","Aman",65000.0),("Sales","Sara",80000.0)).toDF("dept","name","salary")
  df.agg(count("*").as("rows"),sum("salary").as("total"),avg("salary").as("avg"),min("salary").as("min"),max("salary").as("max")).show()
  df.groupBy("dept").agg(count("*").as("employees"),sum("salary").as("revenue"),avg("salary").as("avg_salary")).filter($"revenue">130000).show()
  spark.stop()
}
