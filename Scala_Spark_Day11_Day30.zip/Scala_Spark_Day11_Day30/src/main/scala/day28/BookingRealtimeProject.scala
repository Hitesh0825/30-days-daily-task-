package day28
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object BookingRealtimeProject extends App {
  val spark=SparkSession.builder().appName("Day28").master("local[*]").getOrCreate(); import spark.implicits._
  val events=Seq(("E1","FL1","B1",2,"BOOK"),("E2","FL1","B1",1,"CANCEL"),("E3","FL1","B1",3,"BOOK"),("E4","FL2","B2",4,"BOOK")).toDF("event","service","route","seats","status")
  val ref=Seq(("FL1",180),("FL2",200)).toDF("service","capacity")
  val booking=events.join(broadcast(ref),"service").withColumn("signed_seats",when($"status" === "BOOK",$"seats").otherwise(-$"seats"))
  val state=booking.groupBy("service").agg(sum("signed_seats").as("occupied"),max("capacity").as("capacity")).withColumn("available",$"capacity"-$"occupied")
  state.show(); println("Real-time extension: maintain booking/cancellation state with streaming state store and emit availability updates."); spark.stop()
}
