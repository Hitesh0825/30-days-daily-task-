package day25
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds,StreamingContext}
object WindowOperationsApp extends App {
  val conf=new SparkConf().setAppName("Day25").setMaster("local[2]"); val ssc=new StreamingContext(conf,Seconds(5)); val stream=ssc.socketTextStream("localhost",9997)
  val amounts=stream.flatMap(_.split("\\s+")).flatMap(x=>scala.util.Try(x.toDouble).toOption)
  amounts.countByWindow(Seconds(20),Seconds(10)).print()
  amounts.map(x=>("sales",x)).reduceByKeyAndWindow(_+_,Seconds(20),Seconds(10)).print()
  println("Batch interval=5s, window=20s, sliding interval=10s. This gives overlapping rolling windows.")
  ssc.start(); ssc.awaitTerminationOrTimeout(30000); ssc.stop(true,true)
}
