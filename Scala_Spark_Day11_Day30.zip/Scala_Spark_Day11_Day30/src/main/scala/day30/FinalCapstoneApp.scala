package day30
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
object FinalCapstoneApp extends App {
  val spark=SparkSession.builder().appName("Day30").master("local[*]").getOrCreate(); import spark.implicits._
  val tx=Seq(("T1","A1","P1",2,100.0,"2026-10-08"),("T2","A1","P2",1,300.0,"2026-10-08"),("T3","A2","P1",1,100.0,"2026-10-08"),("T4","A3","P3",5,50.0,"2026-10-08")).toDF("txn","account","product","qty","price","date")
  val accounts=Seq(("A1","Retail"),("A2","Premium"),("A3","Retail")).toDF("account","segment")
  val clean=tx.filter($"qty">0 && $"price">0)
  val enriched=clean.join(broadcast(accounts),"account").withColumn("revenue",$"qty"*$"price").persist()
  val w=Window.partitionBy("segment").orderBy($"revenue".desc)
  val report=enriched.withColumn("rank",dense_rank().over(w)).groupBy("date","segment").agg(sum("revenue").as("revenue"),count("txn").as("transactions"),max("rank").as("max_rank"))
  report.show(); report.write.mode("overwrite").partitionBy("date").parquet("output/day30/report")
  println("Capstone checklist: broadcast=used, accumulator=covered in Day26, cache/persist=used, partitioned output=used, SQL/DataFrame/window/join/aggregation=used.")
  println("Interview topics: DAG, lineage, stages, tasks, executors, shuffle, narrow/wide transformations, partition tuning, skew, Catalyst, YARN.")
  enriched.explain(true); enriched.unpersist(); spark.stop()
}
