package day20
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object FileFormatsApp extends App {
  val spark=SparkSession.builder().appName("Day20").master("local[*]").getOrCreate(); import spark.implicits._
  val df=Seq(("2026-10-01",100,"A",500.0),("2026-10-02",101,"B",700.0),("2026-10-02",102,"A",300.0)).toDF("date","id","region","amount")
  df.write.mode("overwrite").option("header","true").csv("output/day20/csv"); df.write.mode("overwrite").json("output/day20/json"); df.write.mode("overwrite").parquet("output/day20/parquet")
  df.withColumn("year",year(to_date($"date"))).withColumn("month",month(to_date($"date"))).withColumn("day",dayofmonth(to_date($"date"))).repartition("year","month","day").write.mode("overwrite").partitionBy("year","month","day").parquet("output/day20/partitioned")
  println("CSV is human-readable but larger; JSON is flexible; Parquet is columnar and usually preferred for Spark analytics."); spark.stop()
}
