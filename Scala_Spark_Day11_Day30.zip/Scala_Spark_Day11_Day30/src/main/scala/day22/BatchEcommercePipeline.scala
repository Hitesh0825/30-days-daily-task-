package day22
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object BatchEcommercePipeline extends App {
  val spark=SparkSession.builder().appName("Day22").master("local[*]").getOrCreate(); import spark.implicits._
  val tx=Seq((1,101,201,2,500.0),(2,102,202,1,700.0),(3,999,201,-2,500.0),(4,101,202,3,700.0)).toDF("txn_id","customer_id","product_id","qty","unit_price")
  val customers=Seq((101,"Asha","Hyd"),(102,"Ravi","Delhi")).toDF("customer_id","customer","city")
  val products=Seq((201,"Laptop","Electronics"),(202,"Phone","Electronics")).toDF("product_id","product","category")
  val clean=tx.filter($"qty">0 && $"unit_price">0)
  val enriched=clean.join(customers,Seq("customer_id"),"left").join(products,Seq("product_id"),"left").withColumn("revenue",$"qty"*$"unit_price").withColumn("date",lit("2026-10-08"))
  val result=enriched.groupBy("date","city","category").agg(sum("revenue").as("revenue"),count("txn_id").as("orders"))
  result.show(); result.write.mode("overwrite").partitionBy("date").parquet("output/day22/daily_sales")
  spark.stop()
}
