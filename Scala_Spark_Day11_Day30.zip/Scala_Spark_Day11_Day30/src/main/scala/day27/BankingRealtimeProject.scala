package day27
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object BankingRealtimeProject extends App {
  val spark=SparkSession.builder().appName("Day27").master("local[*]").getOrCreate(); import spark.implicits._
  val tx=Seq(("T1","A1","B1",500.0),("T2","A1","B1",700.0),("T3","A1","B1",900.0),("T4","A2","B2",100.0)).toDF("txn","account","branch_id","amount")
  val branch=Seq(("B1","HYD","LOW"),("B2","DEL","HIGH")).toDF("branch_id","city","risk")
  val enriched=tx.join(broadcast(branch),Seq("branch_id")).cache()
  enriched.groupBy("account").agg(sum("amount").as("total"),count("txn").as("txn_count")).show()
  enriched.groupBy("account").count().filter($"count">2).withColumn("suspicious",lit(true)).show(); enriched.explain(true); enriched.unpersist(); println("YARN deployment: driver runs application coordination; executors run tasks; resource manager allocates containers/resources."); spark.stop()
}
