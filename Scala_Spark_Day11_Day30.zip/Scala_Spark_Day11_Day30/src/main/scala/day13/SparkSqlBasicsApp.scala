package day13
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object SparkSqlBasicsApp extends App {
  val spark=SparkSession.builder().appName("Day13").master("local[*]").getOrCreate(); import spark.implicits._
  val customers=Seq((1,"Asha",25,60000),(2,"Ravi",31,85000),(3,"Neha",28,72000),(4,"Aman",40,95000)).toDF("id","name","age","salary")
  customers.printSchema(); customers.select("name","salary").filter($"salary">70000).show()
  val enriched=customers.withColumn("salary_band",when($"salary">=90000,"HIGH").when($"salary">=70000,"MEDIUM").otherwise("LOW")); enriched.createOrReplaceTempView("customers")
  spark.sql("SELECT salary_band, COUNT(*) AS cnt, ROUND(AVG(salary),2) AS avg_salary FROM customers GROUP BY salary_band ORDER BY avg_salary DESC").show()
  spark.stop()
}
