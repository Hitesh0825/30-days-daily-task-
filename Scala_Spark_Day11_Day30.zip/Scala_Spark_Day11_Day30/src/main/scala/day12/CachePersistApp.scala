package day12
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
object CachePersistApp extends App {
  val spark=SparkSession.builder().appName("Day12").master("local[*]").getOrCreate(); val sc=spark.sparkContext
  val cleaned=sc.parallelize(1 to 100).filter(_ % 3 != 0).map(x => (x,x*x))
  cleaned.persist(StorageLevel.MEMORY_ONLY)
  println(s"Count=${cleaned.count}"); println(s"Sum=${cleaned.map(_._2).sum}"); println(s"First=${cleaned.first}")
  cleaned.unpersist(); val persisted=cleaned.persist(StorageLevel.MEMORY_AND_DISK); println(s"Second count=${persisted.count}"); persisted.unpersist(); spark.stop()
}
