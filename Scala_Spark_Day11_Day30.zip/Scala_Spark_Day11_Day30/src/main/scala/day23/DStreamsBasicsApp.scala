package day23
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds,StreamingContext}
object DStreamsBasicsApp extends App {
  val conf=new SparkConf().setAppName("Day23").setMaster("local[2]")
  val ssc=new StreamingContext(conf,Seconds(5))
  val stream=ssc.socketTextStream("localhost",9999)
  val errors=stream.flatMap(_.split("\\W+")).filter(_.equalsIgnoreCase("ERROR")).map(_=>1).reduce(_+_)
  errors.print(); println("DStreams process data as micro-batches. Start a TCP producer on localhost:9999 before running.")
  ssc.start(); ssc.awaitTerminationOrTimeout(30000); ssc.stop(stopSparkContext=true,stopGracefully=true)
}
