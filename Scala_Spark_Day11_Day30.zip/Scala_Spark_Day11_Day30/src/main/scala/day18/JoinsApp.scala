package day18
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object JoinsApp extends App {
  val spark=SparkSession.builder().appName("Day18").master("local[*]").getOrCreate(); import spark.implicits._
  val orders=Seq((1,101,500),(2,102,700),(3,999,300)).toDF("order_id","customer_id","amount")
  val customers=Seq((101,"Asha"),(102,"Ravi"),(103,"Neha")).toDF("customer_id","name")
  orders.as("o").join(customers.as("c"),$"o.customer_id" === $"c.customer_id","inner").select("order_id","name","amount").show()
  orders.join(customers,Seq("customer_id"),"left").show(); orders.join(customers,Seq("customer_id"),"right").show(); orders.join(customers,Seq("customer_id"),"full").show()
  println("Use aliases to resolve ambiguous columns. Left join may introduce nulls; handle with coalesce/when."); spark.stop()
}
