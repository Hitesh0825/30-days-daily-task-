package day17
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
object WindowFunctionsApp extends App {
  val spark=SparkSession.builder().appName("Day17").master("local[*]").getOrCreate(); import spark.implicits._
  val df=Seq(("IT","Asha",90000L,"2026-01-01"),("IT","Ravi",90000L,"2026-02-01"),("IT","Neha",70000L,"2026-03-01"),("HR","Aman",80000L,"2026-01-10"),("HR","Sara",75000L,"2026-03-10")).toDF("dept","name","salary","dt")
  val w=Window.partitionBy("dept").orderBy(col("salary").desc); df.withColumn("row_number",row_number.over(w)).withColumn("rank",rank.over(w)).withColumn("dense_rank",dense_rank.over(w)).show()
  val customerW=Window.partitionBy(lit(1)).orderBy(col("dt").desc); df.withColumn("prev_salary",lag("salary",1).over(w)).withColumn("next_salary",lead("salary",1).over(w)).show()
  spark.stop()
}
