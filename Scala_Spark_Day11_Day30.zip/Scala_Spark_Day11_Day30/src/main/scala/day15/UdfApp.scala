package day15
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
object UdfApp extends App {
  val spark=SparkSession.builder().appName("Day15").master("local[*]").getOrCreate(); import spark.implicits._
  val df=Seq((1,"Asha",45000.0),(2,"Ravi",85000.0),(3,"Neha",150000.0)).toDF("id","name","salary")
  val bandUdf=udf((s:Double)=>if(s<50000)"LOW" else if(s<100000)"MEDIUM" else "HIGH")
  df.withColumn("band",bandUdf($"salary")).show(); spark.udf.register("salary_band",(s:Double)=>if(s<50000)"LOW" else if(s<100000)"MEDIUM" else "HIGH")
  spark.sql("SELECT salary_band(85000.0) AS band").show(); println("Prefer built-in Spark functions when possible because UDFs can limit optimizer/code-generation opportunities."); spark.stop()
}
