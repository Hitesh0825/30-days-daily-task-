package day21
import org.apache.spark.sql.SparkSession
object SparkCatalogApp extends App {
  val spark=SparkSession.builder().appName("Day21").master("local[*]").config("spark.sql.warehouse.dir","output/warehouse").getOrCreate(); import spark.implicits._
  spark.sql("CREATE DATABASE IF NOT EXISTS hotel_db"); spark.sql("USE hotel_db")
  Seq((1,"HotelA",2,12000.0),(2,"HotelB",4,25000.0)).toDF("booking_id","hotel","nights","amount").write.mode("overwrite").saveAsTable("bookings")
  spark.catalog.listDatabases().show(false); spark.catalog.listTables().show(false); spark.catalog.listColumns("bookings").show(false); spark.sql("SELECT * FROM bookings").show(); spark.stop()
}
