package day29
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
object EcommerceEndToEndProject extends App {
  val spark=SparkSession.builder().appName("Day29").master("local[*]").getOrCreate(); import spark.implicits._
  val raw=spark.sparkContext.parallelize(Seq(("A1","P1",2,100.0),("A2","P2",1,200.0),("A3","P1",-1,100.0)))
  val cleaned=raw.filter(_._3>0)
  val pairRevenue=cleaned.map{case (_,p,q,price)=>(p,q*price)}.reduceByKey(_+_)
  println("PairRDD component:"); pairRevenue.collect().foreach(println)
  val df=cleaned.toDF("customer","product","qty","price").withColumn("revenue",$"qty"*$"price").persist()
  val customerRef=Seq(("A1","HYD"),("A2","DEL"),("A3","BLR")).toDF("customer","city")
  val enriched=df.join(customerRef,"customer")
  val w=Window.partitionBy("city").orderBy($"revenue".desc)
  enriched.withColumn("rank",dense_rank().over(w)).groupBy("city").agg(sum("revenue").as("revenue"),max("rank").as("rows")).show()
  enriched.explain(true); df.unpersist(); println("Optimization choices: filter early, reduceByKey instead of groupByKey for PairRDD, broadcast small reference data, persist reused data, inspect explain plan/shuffles, partition output by business date."); spark.stop()
}
