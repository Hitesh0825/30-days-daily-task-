# Day 30 — Final Capstone + Interview Practice
Final e-commerce capstone combines batch transformations, broadcast, persistence, partitioned Parquet, joins, aggregation and windows. Run `sbt "runMain day30.FinalCapstoneApp"`.

## 20 Interview Questions
1. What is DAG?
2. What is lineage?
3. Job vs stage vs task?
4. What causes a shuffle?
5. Narrow vs wide transformation?
6. reduceByKey vs groupByKey?
7. When use broadcast?
8. What is an accumulator?
9. cache vs persist?
10. repartition vs coalesce?
11. What is partition skew?
12. How does Catalyst optimize SQL?
13. RDD vs DataFrame vs Dataset?
14. Why avoid UDF when built-in exists?
15. Broadcast join vs sort-merge join?
16. What is a window function?
17. What is checkpointing in streaming?
18. What are executors?
19. How would Spark run on YARN?
20. How do you troubleshoot a slow Spark job?
