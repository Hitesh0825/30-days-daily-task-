# Day 26 — Real-Time Healthcare Project
Patient-vital schema; broadcast thresholds; accumulator for abnormal events; abnormal alerts; conceptual window/state extension for repeated abnormal readings. Run `sbt "runMain day26.HealthcareRealtimeProject"`.
