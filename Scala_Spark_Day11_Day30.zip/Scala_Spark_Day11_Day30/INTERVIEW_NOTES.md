# Day 11–30 Quick Interview Notes

- Broadcast: distribute a small read-only object efficiently to executors.
- Accumulator: task-side metric aggregated to driver; do not use it as mutable application state.
- Cache/Persist: keep reused data materialized; storage level controls memory/disk trade-off.
- Catalyst: Spark SQL optimizer that transforms logical plans into optimized physical execution plans.
- Shuffle: data redistribution across partitions; usually expensive because of network, serialization and disk I/O.
- Broadcast join: avoid large-side shuffle when the small relation safely fits executor memory.
- Repartition: reshuffles to change partition count/distribution. Coalesce usually reduces partitions with less/no full shuffle.
- Window: calculates values across related rows without collapsing them like groupBy.
- DStreams: legacy micro-batch streaming API. Structured Streaming is preferred for new applications.
- YARN: resource manager allocates cluster resources; Spark driver coordinates work and executors run tasks.
