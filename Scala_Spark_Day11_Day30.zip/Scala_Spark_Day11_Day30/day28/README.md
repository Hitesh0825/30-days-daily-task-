# Day 28 — Real-Time Booking Project
Booking/cancellation events; maintained seat state; occupancy/availability; Pair-style aggregation; broadcast reference; Spark SQL/DataFrame report. Run `sbt "runMain day28.BookingRealtimeProject"`.
