ThisBuild /version := "1.0.0"
ThisBuild /scalaVersion := "2.13.18"

lazy val root = (project in file("."))
  .settings(
    name := "scala-spark-day11-day30",
    libraryDependencies ++= Seq(
      "org.apache.spark" %% "spark-core" % "4.2.0",
      "org.apache.spark" %% "spark-sql" % "4.2.0",
      "org.apache.spark" %% "spark-streaming" % "4.2.0"
    ),
    Compile / run / fork := true,
    Compile / run / javaOptions ++= Seq(
      "-Dspark.master=local[*]",
      "-Dlog4j.configurationFile=log4j2.properties"
    )
  )
