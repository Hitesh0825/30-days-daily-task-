# Day 27 — Real-Time Banking Project
Transaction schema; account aggregation; suspicious burst detection; broadcast branch/risk reference; cache; explain plan; YARN deployment explanation. Run `sbt "runMain day27.BankingRealtimeProject"`.
