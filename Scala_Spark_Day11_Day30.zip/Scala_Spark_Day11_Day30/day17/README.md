# Day 17 — Window Functions
Tasks: row_number/rank/dense_rank; partition by department; lag/lead; top-N/latest-record patterns. Run `sbt "runMain day17.WindowFunctionsApp"`.
