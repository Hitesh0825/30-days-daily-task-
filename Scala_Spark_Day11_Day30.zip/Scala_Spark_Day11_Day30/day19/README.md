# Day 19 — Broadcast Join
Tasks: large fact + small reference; broadcast join; when appropriate; compare with shuffle join. Run `sbt "runMain day19.BroadcastJoinApp"`.
