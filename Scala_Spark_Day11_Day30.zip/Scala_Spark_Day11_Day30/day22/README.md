# Day 22 — Batch Mini Project: E-commerce
Raw transactions -> clean invalid records -> join customer/product -> calculate revenue -> aggregate -> partitioned Parquet. Run `sbt "runMain day22.BatchEcommercePipeline"`.
