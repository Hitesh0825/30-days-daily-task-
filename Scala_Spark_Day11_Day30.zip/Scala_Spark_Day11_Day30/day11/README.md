# Day 11 — Broadcast and Accumulators
Tasks: broadcast product reference; accumulator bad records; explain why driver variables cannot be distributed state; validate transactions. Run `sbt "runMain day11.BroadcastAccumulatorApp"`.
Transformations: map. Action: collect. Broadcast avoids shipping the same small reference with every task. Accumulator is for metrics, not business state.
