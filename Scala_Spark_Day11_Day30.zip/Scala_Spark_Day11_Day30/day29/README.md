# Day 29 — End-to-End E-commerce Project
Raw -> clean -> enrich -> aggregate. PairRDD handles one component; DataFrame handles another. Includes persistence, join, window, explain plan and optimization notes. Run `sbt "runMain day29.EcommerceEndToEndProject"`.
