# Run Commands

From the project root:

```bash
sbt compile
```

Run individual days:

```bash
sbt "runMain day11.BroadcastAccumulatorApp"
sbt "runMain day12.CachePersistApp"
sbt "runMain day13.SparkSqlBasicsApp"
sbt "runMain day14.DataFrameDatasetApp"
sbt "runMain day15.UdfApp"
sbt "runMain day16.AggregationsApp"
sbt "runMain day17.WindowFunctionsApp"
sbt "runMain day18.JoinsApp"
sbt "runMain day19.BroadcastJoinApp"
sbt "runMain day20.FileFormatsApp"
sbt "runMain day21.SparkCatalogApp"
sbt "runMain day22.BatchEcommercePipeline"
sbt "runMain day23.DStreamsBasicsApp"
sbt "runMain day24.StatefulStreamingApp"
sbt "runMain day25.WindowOperationsApp"
sbt "runMain day26.HealthcareRealtimeProject"
sbt "runMain day27.BankingRealtimeProject"
sbt "runMain day28.BookingRealtimeProject"
sbt "runMain day29.EcommerceEndToEndProject"
sbt "runMain day30.FinalCapstoneApp"
```

For DStreams socket exercises, open a second terminal and run e.g. `nc -lk 9999`, then type messages such as `INFO hello` and `ERROR database failed`.
